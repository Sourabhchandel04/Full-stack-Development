export interface CurrentTabItem {
  url: string;
  favicon: string | undefined;
  summaryTime: number;
  sessions: number;
}
