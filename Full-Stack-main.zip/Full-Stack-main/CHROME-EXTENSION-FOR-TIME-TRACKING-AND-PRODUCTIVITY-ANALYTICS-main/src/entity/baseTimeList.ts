export interface BaseTimeList {
  domain: string;
  time: number;
}
